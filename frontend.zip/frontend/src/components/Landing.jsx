export function Landing() {
  return (
    <div className="relative w-full h-screen flex items-center justify-center overflow-hidden">
      <Content />
      <BackgroundImage src="https://via.placeholder.com/1200x600" />
    </div>
  );
}
